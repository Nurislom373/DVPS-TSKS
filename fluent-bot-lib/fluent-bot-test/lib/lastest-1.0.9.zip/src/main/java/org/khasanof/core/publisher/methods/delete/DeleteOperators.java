package org.khasanof.core.publisher.methods.delete;

/**
 * Author: Nurislom
 * <br/>
 * Date: 18.06.2023
 * <br/>
 * Time: 22:15
 * <br/>
 * Package: org.khasanof.core.executors.methods.delete
 */
public class DeleteOperators {
}
