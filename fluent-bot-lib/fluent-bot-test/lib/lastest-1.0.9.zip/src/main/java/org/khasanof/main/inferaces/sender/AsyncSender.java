package org.khasanof.main.inferaces.sender;

/**
 * Author: Nurislom
 * <br/>
 * Date: 19.06.2023
 * <br/>
 * Time: 22:58
 * <br/>
 * Package: org.khasanof.main.inferaces.sender
 */
public interface AsyncSender {

    AsyncSender execute();

}
