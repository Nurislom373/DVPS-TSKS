package org.khasanof.main.inferaces.executor;

/**
 * Author: Nurislom
 * <br/>
 * Date: 18.06.2023
 * <br/>
 * Time: 10:57
 * <br/>
 * Package: org.khasanof.main.inferaces
 */
public interface CallbackExecutor extends Executor {
}
