package org.khasanof.core.publisher.methods.update;

/**
 * Author: Nurislom
 * <br/>
 * Date: 18.06.2023
 * <br/>
 * Time: 22:15
 * <br/>
 * Package: org.khasanof.core.executors.methods.update
 */
public class UpdateOperators {
}
