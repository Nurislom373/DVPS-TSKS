package org.khasanof.core.enums;

/**
 * @author Nurislom
 * @see org.khasanof.core.enums
 * @since 07.07.2023 23:28
 */
public enum MemoryUnits {
    KB,
    MB,
    GB
}
