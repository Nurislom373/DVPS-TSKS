package org.khasanof.core.config;

import org.khasanof.core.enums.ProcessType;
import org.khasanof.core.utils.MethodUtils;
import org.khasanof.core.utils.ReflectionUtils;
import org.reflections.Reflections;

import java.util.ResourceBundle;
import java.util.Set;

/**
 * @author Nurislom
 * @see org.khasanof.core.config
 * @since 05.07.2023 0:29
 */
public class CommonFluentConfig implements FluentConfig {

    private final Reflections reflections = ReflectionUtils.getReflections();
    public static final ResourceBundle settings = ResourceBundle.getBundle("application");

    public static ProcessType getProcessType() {
        return ProcessType.valueOf(settings.getString("bot.process.type"));
    }

    @Override
    public void start() {
        Set<Class<? extends Config>> classes = reflections.getSubTypesOf(Config.class);
        classes.stream().filter(MethodUtils::checkInstance).map(clazz -> {
            try {
                return clazz.newInstance();
            } catch (InstantiationException | IllegalAccessException e) {
                throw new RuntimeException(e);
            }
        }).forEach(Config::runnable);
    }
}
