package org.khasanof.core.enums;

/**
 * @author Nurislom
 * @see org.khasanof.core.enums
 * @since 09.07.2023 18:28
 */
public enum ProcessType {
    BOTH, STATE, UPDATE
}
