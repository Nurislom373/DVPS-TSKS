package org.khasanof.core.config;

/**
 * @author Nurislom
 * @see org.khasanof.core.config
 * @since 19.07.2023 20:31
 */
public interface FluentConfig {

    void start();

    static FluentConfig getInstance() {
        return new CommonFluentConfig();
    }

}
