package org.khasanof.core.enums;

/**
 * @author Nurislom
 * @see org.khasanof.core.enums
 * @since 07.07.2023 22:21
 */
public enum MultiMatchScope {
    ANY_MATCH, ALL_MATCH, NONE_MATCH
}
