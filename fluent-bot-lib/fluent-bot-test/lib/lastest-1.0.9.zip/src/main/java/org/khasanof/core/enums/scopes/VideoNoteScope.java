package org.khasanof.core.enums.scopes;

/**
 * @author Nurislom
 * @see org.khasanof.core.enums.scopes
 * @since 09.07.2023 16:45
 */
public enum VideoNoteScope {
    FILE_SIZE, DURATION
}
