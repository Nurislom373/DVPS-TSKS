package org.khasanof.core.enums;

/**
 * Author: Nurislom
 * <br/>
 * Date: 23.06.2023
 * <br/>
 * Time: 22:51
 * <br/>
 * Package: org.khasanof.core.enums
 */
public enum Proceed {
    PROCEED, NOT_PROCEED
}
