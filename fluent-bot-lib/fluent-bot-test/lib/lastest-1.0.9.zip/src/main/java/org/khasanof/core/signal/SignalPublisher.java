package org.khasanof.core.signal;

/**
 * @author Nurislom
 * @see org.khasanof.core.signal
 * @since 09.07.2023 15:53
 */
public interface SignalPublisher {



}
