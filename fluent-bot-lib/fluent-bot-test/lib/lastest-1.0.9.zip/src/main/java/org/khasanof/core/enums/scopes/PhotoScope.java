package org.khasanof.core.enums.scopes;

/**
 * @author Nurislom
 * @see org.khasanof.core.enums
 * @since 06.07.2023 22:32
 */
public enum PhotoScope {
    FILE_SIZE, WIDTH, HEIGHT
}
