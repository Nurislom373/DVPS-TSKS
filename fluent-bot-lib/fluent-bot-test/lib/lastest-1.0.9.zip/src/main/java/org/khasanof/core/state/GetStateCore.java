package org.khasanof.core.state;

/**
 * @author Nurislom
 * @see org.khasanof.core.state
 * @since 19.07.2023 11:52
 */
public interface GetStateCore {

    StateCore getCore();

}
