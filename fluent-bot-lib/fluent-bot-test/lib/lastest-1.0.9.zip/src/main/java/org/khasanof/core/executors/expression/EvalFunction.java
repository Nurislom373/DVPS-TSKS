package org.khasanof.core.executors.expression;

/**
 * @author Nurislom
 * @see org.khasanof.core.executors.expression
 * @since 05.07.2023 22:30
 */
public interface EvalFunction {

    String getName();

}
