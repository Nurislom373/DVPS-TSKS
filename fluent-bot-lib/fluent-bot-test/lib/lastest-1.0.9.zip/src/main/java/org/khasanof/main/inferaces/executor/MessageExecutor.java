package org.khasanof.main.inferaces.executor;

import org.khasanof.core.enums.ExecutorType;

/**
 * Author: Nurislom
 * <br/>
 * Date: 18.06.2023
 * <br/>
 * Time: 10:57
 * <br/>
 * Package: org.khasanof.main.inferaces
 */
public interface MessageExecutor extends Executor {

}
