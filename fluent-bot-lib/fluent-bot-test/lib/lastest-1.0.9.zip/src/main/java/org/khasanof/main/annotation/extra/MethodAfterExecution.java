package org.khasanof.main.annotation.extra;

/**
 * Author: Nurislom
 * <br/>
 * Date: 21.06.2023
 * <br/>
 * Time: 23:45
 * <br/>
 * Package: org.khasanof.main.annotation
 */
public @interface MethodAfterExecution {
}
