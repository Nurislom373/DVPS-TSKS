package org.khasanof.hello.subhello.boom2;

/**
 * Author: Nurislom
 * <br/>
 * Date: 23.06.2023
 * <br/>
 * Time: 22:34
 * <br/>
 * Package: org.khasanof.hello.subhello.boom2
 */
public class Test {
}
