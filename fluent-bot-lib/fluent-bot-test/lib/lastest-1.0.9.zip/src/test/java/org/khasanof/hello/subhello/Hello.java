package org.khasanof.hello.subhello;

/**
 * Author: Nurislom
 * <br/>
 * Date: 22.06.2023
 * <br/>
 * Time: 22:19
 * <br/>
 * Package: org.khasanof.hello.subhello
 */
public class Hello {
}
