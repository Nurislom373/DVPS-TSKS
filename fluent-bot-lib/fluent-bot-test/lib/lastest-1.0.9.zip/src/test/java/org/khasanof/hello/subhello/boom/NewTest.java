package org.khasanof.hello.subhello.boom;

/**
 * Author: Nurislom
 * <br/>
 * Date: 22.06.2023
 * <br/>
 * Time: 22:32
 * <br/>
 * Package: org.khasanof.hello.subhello.boom
 */
public class NewTest {
}
